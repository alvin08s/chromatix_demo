#ifndef __SENSOR_DBG_H__
#define __SENSOR_DBG_H__

#define SLOW(fmt, args...) do{}while(0)
#define SHIGH(fmt, args...) do{}while(0)
#define SERR(fmt, args...) do{}while(0)
#define ALOGE(fmt, args...) do{}while(0)

#endif /* __SENSOR_DBG_H__ */
