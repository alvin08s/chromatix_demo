/*==========================================================

  Copyright (c) 2015 Qualcomm Technologies, Inc. All Rights Reserved.
  Qualcomm Technologies Proprietary and Confidential.

==========================================================*/
#ifndef CHROMATIX_SW_POSTPROC_H
#define CHROMATIX_SW_POSTPROC_H

#include "chromatix.h"

/***************************************************************************************/
/***************************************************************************************/
/***************************************************************************************/
//  SW Algorithms ( CAC2 + RNR1  )
/*************************************************************************************/
/*************************************************************************************/
/*************************************************************************************/
#define MAX_HYSTERESIS_LIGHT_REGIONS 2 // Bright to Normal Light and Normal Light to Low Light Transitions
#define RNR_LUT_SIZE 164  // (Radius)/16-> for 4208x3120 , size is 164 = sqrt ( pow(2104,2)+pow(1560,2))
#define MAX_SIGMA_TABLES 3

typedef struct
{
    trigger_point_type           rnr_trigger        ;
    unsigned char              sampling_factor    ;     // Def 2,2,4,4,8,8
    float                        center_noise_sigma;         // center noise
    float                         center_noise_weight;     // default to 1.0
    float                      weight_order;             // Def 2,2,1.5,1.5,1.0,1.0
} chromatix_radial_noise_reduction1_type ;
typedef struct
{
    int                                     rnr_enable;
    int                                     rnr_control_enable;
    tuning_control_type                        control_rnr; //DEFAULT 0 lux idx
    int                                        lut_size ;
    trigger_point_type                         hysteresis_point[MAX_HYSTERESIS_LIGHT_REGIONS];
    trigger_point_type                        sigma_lut_trigger[MAX_SIGMA_TABLES-1];
    float                                      sigma_lut[MAX_SIGMA_TABLES][RNR_LUT_SIZE] ;
    chromatix_radial_noise_reduction1_type     rnr_data[MAX_LIGHT_TYPES_FOR_SPATIAL];
} chromatix_RNR1_type;





typedef struct
{
    int                         cac2_enable ;
    trigger_point_type            cac2_trigger        ;
    int                         y_spot_thr_low; //NEW Detection_TH1;         //
    int                         y_spot_thr_up; // NEW Detection_TH2;         //
    int                         y_saturation_thr; // NEW Detection_TH3;        //
    int                         c_saturation_thr; //NEW Verification_TH1;      //
    int                         y_spot_thr_weight; //NEW Correction_Strength;   //u8Q6
    int                            c_spot_thr; //NEW
} chromatix_chroma_aliasing_correction2;

typedef struct
{
    int                                         cac2_control_enable;
    tuning_control_type                               control_cac2; //DEFAULT 0 lux idx
    chromatix_chroma_aliasing_correction2         cac2_data[MAX_LIGHT_TYPES_FOR_SPATIAL];
} chromatix_CAC2_type;

/******************************************************************************
******************************************************************************
    CHROMATIX HEADER definition
******************************************************************************
 ******************************************************************************/


typedef struct {
    chromatix_version_type chromatix_version;
    chromatix_app_version_type chromatix_app_version; // 0x304, version of Chromatix that generated the file
    unsigned char is_compressed;
    unsigned short revision_number;
    /******************************************************************************
    ******************************************************************************/

    chromatix_RNR1_type                chromatix_radial_noise1_reduction ;
    /******************************************************************************
    ******************************************************************************/
    chromatix_CAC2_type               chromatix_CAC2_data ;

} chromatix_sw_postproc_type;

#endif
