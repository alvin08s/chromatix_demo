/*==========================================================

  Copyright (c) 2015 Qualcomm Technologies, Inc. All Rights Reserved.
  Qualcomm Technologies Proprietary and Confidential.

==========================================================*/
#ifndef CHROMATIX_VFE_COMMON_H
#define CHROMATIX_VFE_COMMON_H

#include "chromatix.h"
#include "chromatix_3a.h"
/*============================================================================
                        CONSTANTS
============================================================================*/

#define CHROMATIX_VFE_COMMON_VERSION 0x308

/******************************************************************************
    VFE basic struct
    ******************************************************************************/

//0x304
/******************************************************************************
Pedestal correction type
2-D black correction to To replace the single black point
******************************************************************************/
#define MESH_PedestalTable_SIZE    (13 * 10)

typedef struct
{
    unsigned short         mesh_pedestal_table_size;     // TableSize

    unsigned short     channel_black_level_r[MESH_PedestalTable_SIZE]; //12u
    unsigned short     channel_black_level_gr[MESH_PedestalTable_SIZE]; //12u
    unsigned short     channel_black_level_gb[MESH_PedestalTable_SIZE]; //12u
    unsigned short     channel_black_level_b[MESH_PedestalTable_SIZE]; //12u
} pedestalcorrection_table;

typedef struct
{
    int pedestalcorrection_enable;
    int pedestalcorrection_control_enable;

    pedestalcorrection_table pctable[2]; //need 2 for HDR (T1 and T2)
} chromatix_pedestalcorrection_type;


/******************************************************************************
Linearization data types
******************************************************************************/

typedef struct
{
    unsigned short r_lut_p[8]; // 12uQ0
    unsigned short r_lut_base[9]; // 12uQ0
    // float r_lut_delta[9]; // 18uQ9 //0x0305
    // GR channel knee points & LUT (2 banks)
    unsigned short gr_lut_p[8]; // 12uQ0
    unsigned short gr_lut_base[9]; // 12uQ0
    // float gr_lut_delta[9]; // 18uQ9 //0x0305
    // GB channel knee points & LUT (2 banks)
    unsigned short gb_lut_p[8]; // 12uQ0
    unsigned short gb_lut_base[9]; // 12uQ0
    // float gb_lut_delta[9]; // 18uQ9 //0x0305
    // B channel knee points & LUT (2 banks)
    unsigned short b_lut_p[8]; // 12uQ0
    unsigned short b_lut_base[9]; // 12uQ0
    // float b_lut_delta[9]; // 18uQ9 //0x0305
} chromatix_linearization_type;

typedef struct
{
    unsigned short black_level_offset ;
}Chromatix_BLSS_type ;

/******************************************************************************
roll-off data types
******************************************************************************/
typedef enum
{
    ROLLOFF_TL84_LIGHT, /* Flourescent */
    ROLLOFF_A_LIGHT,    /* Incandescent */
    ROLLOFF_D65_LIGHT,  /* Day Light */
    ROLLOFF_H_LIGHT,  /* Horizon */    // 306
    ROLLOFF_MAX_LIGHT,
    ROLLOFF_INVALID_LIGHT = ROLLOFF_MAX_LIGHT
} chromatix_rolloff_light_type;

#define MESH_ROLLOFF_SIZE    (17 * 13) //0x302

typedef struct
{
    unsigned short         mesh_rolloff_table_size;     // TableSize

    float                  r_gain[MESH_ROLLOFF_SIZE];   // RGain

    float                  gr_gain[MESH_ROLLOFF_SIZE];  // GRGain

    float                  gb_gain[MESH_ROLLOFF_SIZE];  // GBGain

    float                  b_gain[MESH_ROLLOFF_SIZE];   // BGain
} mesh_rolloff_array_type;

typedef struct
{
    int linearization_enable;
    int linearization_control_enable;

    tuning_control_type control_linearization;
    trigger_point_type linearization_lowlight_trigger;

    chromatix_linearization_type linear_table_lowlight;
    chromatix_linearization_type linear_table_normal;
    // CCT tables - 0x305 Removal
    // chromatix_CCT_trigger_type linear_A_trigger;
    // chromatix_CCT_trigger_type linear_D65_trigger; // 0x305
    // chromatix_linearization_type linear_table_A_lowlight;
    // chromatix_linearization_type linear_table_A_normal;
    // chromatix_linearization_type linear_table_TL84_lowlight;
    // chromatix_linearization_type linear_table_TL84_normal;
    // chromatix_linearization_type linear_table_Day_lowlight;
    // chromatix_linearization_type linear_table_Day_normal;
} chromatix_L_type;
typedef struct
{
    int BLSS_enable;
    int BLSS_control_enable;

    tuning_control_type control_BLSS;
    trigger_point_type     BLSS_low_light_trigger;

    Chromatix_BLSS_type black_level_lowlight;
    Chromatix_BLSS_type black_level_normal;
} Chromatix_blk_subtract_scale_type;

typedef struct
{
    chromatix_CCT_trigger_type    rolloff_H_trigger; // 306
    chromatix_CCT_trigger_type    rolloff_A_trigger;
    chromatix_CCT_trigger_type    rolloff_D65_trigger;

    float rolloff_LED_start;
    float rolloff_LED_end ;
    float rolloff_Strobe_start;
    float rolloff_Strobe_end;

    //0x303
    int scale_cubic; // bicubic interpolation scale from grid to subgrid
    int subgridh_offset;    // horizontal size of subgrid
    int subgridv_offset;    // vertical size of subgrid

    mesh_rolloff_array_type                chromatix_mesh_rolloff_table[ROLLOFF_MAX_LIGHT]; // Mesh
    mesh_rolloff_array_type                chromatix_mesh_rolloff_table_lowlight[ROLLOFF_MAX_LIGHT]; // NEW
    mesh_rolloff_array_type                chromatix_mesh_rolloff_table_golden_module[ROLLOFF_MAX_LIGHT]; // NEW
    mesh_rolloff_array_type                chromatix_mesh_rolloff_table_LED;
    mesh_rolloff_array_type                chromatix_mesh_rolloff_table_Strobe;
} chromatix_rolloff_type;

typedef struct
{

    float LA_LUT_backlit[64];
    float LA_LUT_solarize[64];
    float LA_LUT_posterize[64];
    float LA_LUT_blackboard[64];
    float LA_LUT_whiteboard[64];
} chromatix_LA_special_effects_type;

/******************************************************************************
******************************************************************************
******************************************************************************
******************************************************************************
******************************************************************************
******************************************************************************
    CHROMATIX COMMON VFE HEADER definition
 ******************************************************************************
 ******************************************************************************
 ******************************************************************************
 ******************************************************************************
 ******************************************************************************
 ******************************************************************************/

typedef struct
{
//common structs

    chromatix_version_type    chromatix_version;
    chromatix_app_version_type chromatix_app_version; // 0x304, version of Chromatix that generated the file
    unsigned char            is_compressed;

    unsigned short          revision_number;

    /******************************************************************************
    Pedestal correction type:
    2-D black correction to To replace the single black point in 0x304
    ******************************************************************************/
    chromatix_pedestalcorrection_type chromatix_pedestal_correction;

    /******************************************************************************
    Linearization
    ******************************************************************************/
    chromatix_L_type       chromatix_L;
    /******************************************************************************
    Black Level Substract and Scaling
    ******************************************************************************/
    Chromatix_blk_subtract_scale_type Chromatix_BLSS_data ;
    /******************************************************************************
    Lens Rolloff   (Rolloff)
    ******************************************************************************/
    chromatix_rolloff_type chromatix_rolloff;

    /******************************************************************************
    Luma adaptation
    These are parameters for special effect, manual BSM
    ******************************************************************************/
    chromatix_LA_special_effects_type chromatix_LA_special_effects;
} chromatix_VFE_common_type;

#endif
