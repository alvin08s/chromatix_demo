/*==========================================================

  Copyright (c) 2015 Qualcomm Technologies, Inc. All Rights Reserved.
  Qualcomm Technologies Proprietary and Confidential.

==========================================================*/
#ifndef CHROMATIX_3A_H
#define CHROMATIX_3A_H

#include "chromatix.h"

typedef struct {
unsigned short chromatix_version;
unsigned short AAA_header_version;
} AAA_version_type;

/*============================================================================
                        CONSTANTS
============================================================================*/


// Generic package for 3 RGB float parameters
typedef struct
{
    float r;
    float g;
    float b;
} chromatix_float_rgb_type;

typedef enum _af_kernel_type {
  AF_KERNEL_PRIMARY = 0,
  AF_KERNEL_SCALE,
} af_kernel_type;

#ifndef MAX_HPF_BUFF_SIZE
#define MAX_HPF_BUFF_SIZE 22
#endif


/******************************************************************************
AAA sync related data types; Used for dual sensor configurations.
******************************************************************************/

typedef enum
{
    AWB_SYNC_MODE_DISABLE = 0,            // Not synchronized (Default)
    AWB_SYNC_MODE_SAME_SCALERS,            // Copy master's WBC to slave
    AWB_SYNC_MODE_STATIC_CORRECTION,    // Master's WBC multiplied by static correction
    AWB_SYNC_MODE_DYNAMIC_CORRECTION,    // Dynamic olcm
} chromatix_awb_sync_mode_type;

typedef struct
{
    chromatix_awb_sync_mode_type    mode;                    // Default = AWB_SYNC_MODE_DISABLE
    chromatix_float_rgb_type          correction;                  // rgb gains for fixed correction.
    float                               aggressiveness;         // Speed of correction changes
    float                            trans_ms;                // (msec) Transition time  on mode changes. Default = 1000ms
} chromatix_awb_sync_type;

typedef enum
{
    AEC_SYNC_MODE_DISABLE = 0,    // Not synchronized (Default)
    AEC_SYNC_MODE_ENABLE,        // Match master sensor's exposure
} chromatix_aec_sync_mode_type;


typedef struct
{
    chromatix_aec_sync_mode_type    mode;        // Default = AEC_SYNC_MODE_DISABLE
    float                             correction; // exposure multiplier, compensating for different sensetivity and/or aperture. Default 1.0f
    float                            trans_ms;    // (msec) Transition time  on mode changes. Default = 1000ms
} chromatix_aec_sync_type;

typedef struct
{
    chromatix_aec_sync_type aec;
    chromatix_awb_sync_type awb;
} chromatix_aaa_sync_type;

typedef enum
{
    FACE_PRIORITY_CENTER=0,  // default
    FACE_PRIORITY_BIG,       // big face
    FACE_MAX_PRIORITY,
    FACE_INVALID_PRIORITY=FACE_MAX_PRIORITY
} chromatix_face_priority_type;
/******************************************************************************
    ASD basic struct
    ******************************************************************************/

typedef struct
{
    //Snow/cloudy Scene Detection

    int snow_scene_detection_enable; // TRUE enables the feature from AEC perspective, FALSE disables the feature.
    unsigned long y_cloudy_snow_threshold; // AE region?s min luma to be considered a potential snow/cloudy region.
    unsigned long awb_y_max_in_grey; // Any AE region above this threshold is considered potential snow/cloudy region.  These regions will not have WB data because WB considered too bright and above YMAX WB configuration.
    unsigned long min_snow_cloudy_sample_th; // If count of snow/cloudy regions detected above this threshold, we consider the scene as snow/cloudy.
    unsigned long extreme_snow_cloudy_sample_th; // if count of detected snow regions above this threshold, scene is considered extreme snow/cloudy scene.  Luma offset is maxed.
    float extreme_luma_target_offset;// Maximum luma offset that can be applied when scnow scene is detected.  This happens when extreme_snow_cloudy_sample_th is reached or exceeded.  Luma offset is gradually reduced for darker scenes until eventually made 0 for indoor cases, this is based on exp_index. (cannot use lux_idx due to rapid change based on frame luma, will cause luma offset to be unstable).
    unsigned int snow_scene_indoor_index;      // Use dedicated index for indoor/outdoor distinguish
    unsigned int snow_scene_outdoor_index;     // Use dedicated index for indoor/outdoor distinguish
    unsigned long severe_snow_scene_cap; //? At what point will ?extreme_luma_target_offset? be applied, value is 0 to 255 for severity.  255 means snow scene detection must report 255 severity for extreme_luma_target_offset to be applied.
    float snowscene_aggressiveness;
    unsigned char ui_snow_cloudy_display_th;
} snow_scene_detect_type;

typedef struct
{
    int backlight_detection_enable; //TRUE enables the feature from AEC perspective, FALSE disables the feature.
    float histogram_offset;
    unsigned long low_luma_threshold; // Histogram samples which luma is below this threshold are added to low luma count.
    unsigned long high_luma_threshold; // Histogram samples which luma is above this threshold are added to high luma count.
    float low_luma_count_percent_threshold ; // If count of low luma samples exceed this percentage of total samples, we consider potential backlight case.
    float high_luma_count_percent_threshold ;// If count of high luma samples exceed this percentage of total samples, we consider potential backlight case.
    float kept_pixel_ratio_th;
    int backlight_max_la_luma_target_offset; // Maximum luma target adjustment when backlight is detected.   We expect to increase luma target.
    float backlit_aggressiveness;
    float    max_percent_threshold; //defines interpolation range of backlit severity in         //histogram detector.
    unsigned char ui_backlit_display_th;
} backlit_scene_detect_type;

typedef struct
{
    float backlight_high_threshold;
    float backlight_low_threshold;
    float portrait_high_threshold;
    float portrait_low_threshold;
} auto_hdr_detect_type;

typedef struct
{
  int landscape_detection_enable; //TRUE enables the feature ,FALSE disables the feature.
  float landscape_red_boost_factor;
  float landscape_green_boost_factor;
  float landscape_blue_boost_factor;
  float min_blue_green_content_detection_threshold; //min detection
  float max_blue_green_content_detection_threshold; //stop interpolation detection range
  int   green_offset_rg; //for extreme green zone boundary config
  int   green_offset_bg; //for extreme green zone boundary config
  float asd_ext_blue_th;   //extreme blue region detection
  float asd_ext_green_th_r;  //extreme green region detection
  float asd_ext_green_th_b;  //extreme green region detection
  float aggressiveness;  //response of temporal filter to severity change
  long lux_idx_indoor;  //lux_idx above this threshold disabled landscape detection
  long lux_idx_outdoor; //lux idx below this threshold has full application of landscape scene compensation.  Between indoor and outdoor, we interpolate severity.
  unsigned char ui_landscape_display_th;
} landscape_scene_detect_type;

typedef struct
{
  int portrait_detection_enable;
  float skin_color_boost_factor;
  float min_face_content_threshold;
  float max_face_content_threshold;
  filter_sharpen_degree_type  soft_focus_degree_7_7;
  filter_sharpen_degree_type  soft_focus_degree_5_5;
  float aggressiveness;
  unsigned char ui_portrait_display_th;
} portrait_scene_detect_type;


typedef struct
{
  int           hazy_detection_enable;
  float         hazy_running_frequency;
  float         hazy_detection_threshold_on;
  float         hazy_detection_threshold_off;
  unsigned char    ui_hazy_display_th;
  float         reserved[20];
} hazy_scene_detect_type;

/******************************************************************************
             AWB tuning structurse
******************************************************************************/
#define AGW_NUMBER_GRID_POINT             241
#define MAX_LOW_LIGHT_AWB_LUT_SIZE           6
#define MAX_LED_MIX_LEVEL                   16

/***********************************
AWB tuning parameters are divided into three groups:
Level-0: must tune parameters
Level-1: Performance improvement parameters
Level-3: Least important parameters. Provided for AWB tuning flexibility
************************************/

/*************************
Level-0
**************************/

/**
* Reference light definitions
**/
typedef enum
{
  AGW_AWB_D65 =  0,                // D65
  AGW_AWB_D75,                        // D75
  AGW_AWB_A,                            // A
  AGW_AWB_WARM_FLO,                // TL84
  AGW_AWB_COLD_FLO,                // CW
  AGW_AWB_HORIZON,                // H
  AGW_AWB_D50,                        // D50
  AGW_AWB_CUSTOM_FLO,            // CustFlo
  AGW_AWB_NOON,           // Noon
  AGW_AWB_CUSTOM_DAYLIGHT,
  AGW_AWB_CUSTOM_A,
  AGW_AWB_U30,
  AGW_AWB_CUSTOM_DAYLIGHT1,
  AGW_AWB_CUSTOM_DAYLIGHT2,
  AGW_AWB_CUSTOM_FLO1,
  AGW_AWB_CUSTOM_FLO2,
  AGW_AWB_MAX_LIGHT,
  AGW_AWB_INVALID_LIGHT = AGW_AWB_MAX_LIGHT,
  DAY_LINE_1 = AGW_AWB_MAX_LIGHT,
  DAY_LINE_2,
  FLINE,
  A_LINE_1,
  A_LINE_2,
  AGW_AWB_HYBRID,                                 // Daylight, only used for algorithm, not data
  AGW_AWB_MAX_ALL_LIGHT = AGW_AWB_HYBRID,    // Don't count the hybrid
  AGW_AWB_INVALID_ALL_LIGHT = AGW_AWB_MAX_ALL_LIGHT
} chromatix_awb_all_light_type;

typedef enum
{
  AWB_LOWLIGHT_A=0,
  AWB_LOWLIGHT_TL84,
  AWB_LOWLIGHT_D65,
  AWB_LOWLIGHT_LED,
  AWB_LOWLIGHT_STROBE,
  AWB_MAX_LOWLIGHT
} AWB_LOWLIGHT_type;

/* Manual white balance gains */
typedef struct
{
  /* 9-bit, Q7, unsigned */
  float r_gain;                           // RGain

  /* 9-bit, Q7, unsigned */
  float g_gain;                           // GGain

  /* 9-bit, Q7, unsigned */
  float b_gain;                           // BGain
} chromatix_manual_white_balance_type;

typedef struct
{
  float RG_ratio;                  // RedG
  float BG_ratio;                  // BlueG
} chromatix_awb_reference_type;

typedef struct
{
  float red_gain_adj;               // RedAdj
  float blue_gain_adj;              // BlueAdj
} chromatix_awb_gain_adj_type;


typedef struct
{
  int                     AWB_purple_prevent_enable;
  tuning_control_type     control_purple_prevent;
  trigger_point_type      purple_prevent_trigger;
  float                   purple_sky_prevention_bg_threshold ;
} AWB_purple_prevent_type;


typedef struct
{
  int indoor_weight;                // Indoor
  int outdoor_weight;               // Outdoor
  int inoutdoor_weight;             // InOut
} chromatix_awb_weight_vector_type;

/* AWB sample influence */
typedef struct
{
  float outdoor_influence;          // Outdoor
  float indoor_influence;           // Indoor
} chromatix_awb_sample_influence_type;


typedef struct
{
  float gyro_trigger ;
  float accelerometer_trigger;
  float magnetometer_trigger;
  float DIS_motion_vector_trigger;
} AWB_motion_sensor_type;

typedef struct
{
  int lux_index;
  float green_rg_offset_adj;
  float green_bg_offset_adj;
  float outlier_dist_adj;

} low_light_adj_type;

typedef struct
{
  unsigned char enable;
  low_light_adj_type  lut_entry[MAX_LOW_LIGHT_AWB_LUT_SIZE];
} awb_lowlight_adj_lut_type;


typedef struct
{
  unsigned short CCT;
  unsigned short LED1_setting;
  unsigned short LED2_setting;
  float rg_ratio;
  float bg_ratio;
  float flux;
  float preflash_flux;
  float cont_burst_flux;
} LED_mix_type;


typedef struct
{
  int                         dual_led_enable;
  float                       preflash_current_ratio;
  float                       continuous_burst_current_ratio;
  chromatix_awb_gain_adj_type led1_gain_adj;
  chromatix_awb_gain_adj_type led2_gain_adj;
  unsigned short              table_size;

  LED_mix_type                  CCT_control[MAX_LED_MIX_LEVEL];

} chromatix_match_LED_lighting_table_type;


typedef struct{

  int                            skin_ctrl_enable;
  trigger_point_type            skin_ref_exp_index_trigger;
  chromatix_awb_reference_type    skin_reference[AGW_AWB_MAX_LIGHT];

}awb_skin_control_type;

typedef struct{

    int                            aux_sensor_enable;
    AWB_motion_sensor_type        AWB_motion_sensor_data;

}awb_aux_sensor_type;

typedef struct{

  unsigned char                skip_frames;
  int                          stat_saturation_threshold;
  int                          all_outlier_heuristic_flag;
  int                          valid_per_th;

}awb_flow_control_type;



typedef struct{

    unsigned int awb_day_cluster_left_outlier_distance;
    unsigned int awb_day_cluster_top_outlier_distance;
    unsigned int awb_a_h_cluster_left_outlier_distance;

}awb_cluster_distance_type;



typedef struct{

  unsigned char                awb_interpolate_gain_adj_enable;
  trigger_point_type           exp_index_bright_light_gain_adjust;
  trigger_point_type           exp_index_lowlight_gain_adjust;
  tuning_control_type          control_gain_adj_lowlight;

  chromatix_awb_gain_adj_type  gain_adj_brightlight[AGW_AWB_MAX_LIGHT];
  chromatix_awb_gain_adj_type  gain_adj_normallight[AGW_AWB_MAX_LIGHT];
  chromatix_awb_gain_adj_type  gain_adj_lowlight[AGW_AWB_MAX_LIGHT];

}awb_adjust_gain_table_type;

typedef struct{

  int                            outlier_distance;
  int                            outlier_distance_day;
  int                             outlier_distance_f;
  int                             outlier_distance_a;
  int                             outlier_distance_h;
  int                             outlier_distance_customday;
  int                             outlier_distance_customf;

  awb_cluster_distance_type        special_cluster_distances;

}awb_outlier_distance_type;

typedef struct {

  chromatix_awb_reference_type                reference[AGW_AWB_MAX_LIGHT];
  long                                         indoor_index;
  long                                        outdoor_index;

  chromatix_manual_white_balance_type        awb_min_gains;
  chromatix_manual_white_balance_type        awb_max_gains;

  int                                        awb_self_cal_enable;
  float                                        awb_self_cal_adj_ratio_high;
  float                                        awb_self_cal_adj_ratio_low;

  awb_lowlight_adj_lut_type                    AWB_lowlight_LUT;
  awb_adjust_gain_table_type                awb_adjust_gain_table;
  awb_outlier_distance_type                    outlier_distances;

}awb_basic_tuning_type;

 typedef struct{

  int lowlight_measure_delta;

  int dark_r_threshold;
  int dark_g_threshold;
  int dark_b_threshold;


  int dark_r_threshold_lowlight;
  int dark_g_threshold_lowlight;
  int dark_b_threshold_lowlight;

} awb_dark_threshold_type;

typedef struct{

  int    white_stat_y_threshold_high;
  float white_outlier_valid_ymax_ratio;
  int     white_stat_cnt_threshold;
  int     white_peak_separation_distance;
  int     white_aec_stable_range_threshold;
  float white_history_weight;
  float white_current_weight;

}awb_white_world_struct_type;

typedef struct{
  float                        ref_b_bg_tl84;
  float                     extreme_range_perc_b;
  float                     blue_sky_pec;
  float                     blue_sky_pec_buffer;
  float                     threshold_extreme_b_percent;

  AWB_purple_prevent_type    AWB_purple_prevent;
}awb_blue_sky_type;

typedef struct{

  awb_blue_sky_type        blue_sky_param;
  float                 snow_blue_gain_adj_ratio;
  float                 beach_blue_gain_adj_ratio;

}awb_blue_tuning_type;

typedef struct{
  int grey_weight_day;
  int grey_weight_f;
  int grey_weight_a;
  int grey_weight_h;

  int white_weight_day;
  int white_weight_f;
  int white_weight_a;
  int white_weight_h;

  int exposure_adjustment;
}awb_heuristic_control_type;

typedef struct{
  int     awb_history_buffer_size;

  int     day_stability_enable;
  int     f_stability_enable;
  int     a_stability_enable;
  int     h_stability_enable;

  int     awb_lock_day_enable;
  int     awb_lock_f_enable;
  int     awb_lock_a_enable;
  int     lock_exp_threshold_day;
  int     lock_exp_threshold_f;
  int     lock_exp_threshold_a;

  int     save_historyaverage2history;

  float awb_convergence_factor_camera;
  float awb_convergence_factor_video;
}awb_temporal_tuning_type;


typedef struct{

  int   dominant_cluster_enable;
  float cluster_high_pec;
  float cluster_mid_pec;
  float cluster_low_pec;
  int     threshold_compact_cluster_valid;
  int     threshold_compact_cluster;
  int     compact_to_grey_dis;
  int     dominant_cluster_threshold;

}awb_cluster_tuning_type;



typedef struct{

  int     enable_AWB_module_cal;
  float AWB_golden_module_R_Gr_ratio[AGW_AWB_MAX_LIGHT];
  float AWB_golden_module_Gb_Gr_ratio[AGW_AWB_MAX_LIGHT];
  float AWB_golden_module_B_Gr_ratio[AGW_AWB_MAX_LIGHT];

}awb_golden_module_info_type;


typedef struct{

  float                                     awb_led_strobe_adjustment_factor ;

  chromatix_match_LED_lighting_table_type     mix_LED_table;
  chromatix_awb_gain_adj_type                 LED_gain_adj;
  chromatix_awb_gain_adj_type                 strobe_gain_adj;

}awb_led_tuning_type;

/*********************************************************************/
// Feature name :
// Manual white balance gains for both snapshot and viewfinder.
/*********************************************************************/
typedef struct
{
  chromatix_manual_white_balance_type    MWB_tl84;                    // Flourescent
  chromatix_manual_white_balance_type    MWB_d50;                     // Sunny
  chromatix_manual_white_balance_type    MWB_A;                       // Tungsten
  chromatix_manual_white_balance_type    MWB_d65;                     // Cloudy/Shade
  chromatix_manual_white_balance_type    strobe_flash_white_balance;  // Strobe
  chromatix_manual_white_balance_type    led_flash_white_balance;     // LED

} awb_MWB_type;


typedef struct{

  int directsun_exp_index;
  int outdoor_heuristic_exposure_index_trigger;

}awb_extended_outdoor_exp_trigger_type;

/**********************************/
// Type definition of AWB subzone
/**********************************/
typedef enum{
  AWB_DAY_D75 = 0,                        //Subzone above D75 reference point                                                                       (NOTE: D75 reference weight)
  AWB_DAY_D75_D65_1,                    //1st subzone between D75 and D65 reference points                                                        (NOTE: D75 reference weight)
  AWB_DAY_D75_D65_2,                    //2nd subzone between D75 and D65 reference points
  AWB_DAY_D75_D65_3,                    //3rd subzone between D75 and D65 reference points
  AWB_DAY_D65,                            //4th subzone between D75 and D65 reference points                                                        (NOTE: d65 reference weight)
  AWB_DAY_D65_D50_1,                    //1st subzone between D65 and D50 reference points                                                        (NOTE: d65 reference weight)
  AWB_DAY_D65_D50_2,                    //2nd subzone between D65 and D50 reference points
  AWB_DAY_D65_D50_3,                    //3rd subzone between D65 and D50 reference points
  AWB_DAY_D50,                            //4th subzone between D65 and D50 reference points                                                        (NOTE: d50 reference weight)
  AWB_DAY_NOON_LINE_0,                //Subzone above the shifted D65 reference point                                                                (NOTE: d65 reference weight)
  AWB_DAY_NOON_LINE_1,                //1st subzone between the shifted D65 and the shifted D50 reference points        (NOTE: d65 reference weight)
  AWB_DAY_NOON_LINE_2,                //2nd subzone between the shifted D65 and the shifted D50 reference points
  AWB_DAY_NOON_LINE_3,                //3rd subzone between the shifted D65 and the shifted D50 reference points        (NOTE: Noon reference weight)
  AWB_DAY_NOON_LINE_4,                //4th subzone between the shifted D65 and the shifted D50 reference points        (NOTE: Noon reference weight)
  AWB_DAY_D50_FLO_1,                    //1st subzone between D50 and the center point of Flo line                                        (NOTE: d50 reference weight)
  AWB_DAY_D50_FLO_2,                    //2nd subzone between D50 and the center point of Flo line
  AWB_DAY_D50_FLO_3,                    //3rd subzone between D50 and the center point of Flo line
  AWB_DAY_D50_FLO_4,                    //4th subzone between D50 and the center point of Flo line
  AWB_F_TL84,                              //1sth subzone between CW and TL84 reference points                                                        (NOTE: TL84 reference weight)
    AWB_F_TL84_CW_2,                        //2nd subzone between CW and TL84 reference points
  AWB_F_TL84_CW_3,                        //3rd subzone between CW and TL84 reference points
    AWB_F_CW,                                 //4th subzone between CW and TL84 reference points                                                        (NOTE: CW referece weight)
  AWB_F_FLO_A_1,                            //1st subzone between the center point of Flo line and A reference point
  AWB_F_FLO_A_2,                            //2nd subzone between the center point of Flo line and A reference point
  AWB_F_FLO_A_3,                            //3rd subzone between the center point of Flo line and A reference point
  AWB_A,                            //4th subzone between the center point of Flo line and A reference point            (NOTE: A reference weight)
  AWB_AH_A_H_1,                                //1st subzone between A and H reference points                                                                (NOTE: A reference weight)
  AWB_AH_A_H_2,                                //2nd subzone between A and H reference points
  AWB_AH_A_H_3,                                //3rd subzone between A and H reference points
  AWB_H,                              //4th subzone between A and H reference points                                                                (NOTE: H reference weight)
  AWB_CUSTOM_DAYLIGHT1,                //Custom Day light 1                                                                                                                    (NOTE: Custom day reference weight)
  AWB_CUSTOM_DAYLIGHT2,                //Custom Day light 2                                                                                                                    (NOTE: Custom day1 reference weight)
  AWB_CUSTOM_DAYLIGHT3,                //Custom Day light 3                                                                                                                    (NOTE: Custom day2 reference weight)
  AWB_CUSTOM_FLO1,                //Custom F light 1                                                                                                                        (NOTE: Custom f reference weight)
  AWB_CUSTOM_FLO2,                        //Custom F light 2                                                                                                                        (NOTE: Custom f1 reference weight)
  AWB_CUSTOM_FLO3,                        //Custom F light 3                                                                                                                        (NOTE: Custom f2 reference weight)
  AWB_CUSTOM_A,                                //Custom A light                                                                                                                            (NOTE: Custom A reference weight)
  AWB_U30,                                        //U30 light                                                                                                                                        (NOTE: U30 reference weight)
  AWB_SUBZONE_DECISION_INVALID,
  AGW_AWB_SUBZONE_LIGHT = AWB_SUBZONE_DECISION_INVALID
}awb_hybrid_decision_type;


/**********************************/
// Type definition of Indoor CCM
/**********************************/
typedef enum
{
    CCM_INDOOR_D65=0,        //D65 CCM
    CCM_INDOOR_D50,            //D50 CCM
    CCM_INDOOR_CW,            //CW CCM
    CCM_INDOOR_TL84,        //TL84 CCM
    CCM_INDOOR_A,                //A CCM
    CCM_INDOOR_H,                //Horizon CCM
    CCM_INDOOR_NUM,
}ccm_indoor_entry;

/**********************************/
// Type definition of Outdoor CCM
/**********************************/
typedef enum
{
    CCM_OUTDOOR_SHADE=0,    //Shade (around D75) CCM
    CCM_OUTDOOR_SUNNY,        //Suuny (daylight, D50) CCM
    CCM_OUTDOOR_GREEN,        //Green color CCM
    CCM_OUTDOOR_SKY,            //SKy color CCM
    CCM_OUTDOOR_SKIN,            //Skin color CCM
    CCM_OUTDOOR_LOWLIGHT,    //Low light CCM
    CCM_OUTDOOR_NUM,
}ccm_outdoor_entry;

/**********************************/
// Type definition of Flash (LED) CCM
/**********************************/
typedef enum
{
    CCM_FLASH_LED1=0,                    //Flash CCM under full power for LED1
    CCM_FLASH_LED2,                        //Flash CCM under full power for LED2
    CCM_FLASH_NUM,
}ccm_flash_entry;



#define AWB_FLASH_ADJUST_LUT 5


typedef struct{

  int                            lux_index;
  float                          flash_sensitivity_ratio;
  chromatix_CCT_trigger_type     cct_threshold;
  chromatix_awb_gain_adj_type    adjust_ratio;

}awb_flash_lut_info;

/***************************/
// Feature name: awb_trigger_type_int
// trigger point structure with integer members
/***************************/
typedef struct
{
  int nstart;
  int nend;
}awb_trigger_type_int;

/***************************/
// Feature name: awb_trigger_type_float
// trigger point structure with float members
/***************************/
typedef struct
{
    float fstart;
    float fend;
}awb_trigger_type_float;


typedef struct
{
  float               rg_center;
  float               bg_center;
  int                 rg_radius_grid;
  int                 bg_radius_grid;
}awb_detect_zone_type;


#define DETECT_ZONE_NUM 8

typedef struct
{
  awb_detect_zone_type           detection_zone[DETECT_ZONE_NUM];
  awb_trigger_type_int         count_trigger;
  trigger_point_type           exp_index_trigger;
  float                        aux_cond[2];
  chromatix_awb_gain_adj_type  adjust_ratio;
}awb_outdoor_special_type;


#define WEIGHT_VECTOR_TABLE_SIZE 13

typedef struct{

 int exposure_index;
 int weight_array[AGW_AWB_SUBZONE_LIGHT];

}awb_illuminant_weight_vector_type ;


#define NUM_SPECIAL_COLOR_DETECT 8

typedef struct{
  awb_detect_zone_type           detection_zone[DETECT_ZONE_NUM];
  trigger_point_type           exp_index;
  awb_trigger_type_int         count_offset;
  chromatix_awb_gain_adj_type  adjust_ratio;

}awb_single_color_type;



#define MISLEADING_COLOR_ZONE_NUM 30
#define GREEN_ZONE_ASSIST_NUM 5

typedef struct{
    int                     zone_control;
    int                        trigger_type;
    int                        control_direction;
    awb_detect_zone_type    detect_zone;
  trigger_point_type        exp_index_trigger;

}awb_misleading_zone_type;


typedef struct{
int enable;
chromatix_color_correction_type ccm;
}awb_extended_ccm_type;


typedef struct{

    int                            awb_ccm_enable;
    trigger_point_type             awb_ccm_exp_index_trigger_outdoor;
     trigger_point_type             awb_ccm_exp_index_trigger_lowlight;
    trigger_point_type             awb_ccm_exp_index_trigger_LED_lowlight;
    awb_trigger_type_float         awb_ccm_LED_trigger;
    chromatix_CCT_trigger_type     awb_ccm_cct_trigger_outdoor;
    chromatix_CCT_trigger_type     awb_ccm_cct_trigger_indoor_day;
    chromatix_CCT_trigger_type     awb_ccm_cct_trigger_indoor_dayf;
    chromatix_CCT_trigger_type     awb_ccm_cct_trigger_indoor_fa;
    chromatix_CCT_trigger_type       awb_ccm_cct_trigger_indoor_ah;
    awb_extended_ccm_type           awb_ccm_indoor[CCM_INDOOR_NUM];
    awb_extended_ccm_type             awb_ccm_portrait[CCM_INDOOR_NUM];
    awb_extended_ccm_type          awb_ccm_lowlight[CCM_INDOOR_NUM];
    awb_extended_ccm_type          awb_ccm_outdoor[CCM_OUTDOOR_NUM];
    awb_extended_ccm_type          awb_ccm_flash[CCM_FLASH_NUM];
    awb_extended_ccm_type          awb_ccm_flash_lowlight[CCM_FLASH_NUM];

}awb_CCM_type;



typedef struct{

  awb_illuminant_weight_vector_type      weight_vector[WEIGHT_VECTOR_TABLE_SIZE];
  int                                    distance_weight_table[AGW_NUMBER_GRID_POINT];

}awb_weight_vector_type;





typedef struct{

  int                            awb_exposure_outdoor_heuristic;
  awb_outdoor_special_type      awb_outdoor_green_adjust;
  awb_outdoor_special_type      awb_outdoor_bright_blue_sky_adjust;
  awb_outdoor_special_type      awb_outdoor_not_enough_stat_adjust;
  awb_outdoor_special_type      awb_outdoor_blue_ground_adjust;
  awb_outdoor_special_type      awb_outdoor_cloud_sky_adjust;
  awb_outdoor_special_type      awb_outdoor_blue_sky_adjust;
  awb_outdoor_special_type      awb_outdoor_fog_sky_adjust;
  awb_outdoor_special_type      awb_outdoor_green_detect_adjust;

  chromatix_awb_gain_adj_type   awb_outdoor_no_day_weighted_sample_adjust;
  chromatix_awb_gain_adj_type   awb_outdoor_all_out_of_zone_adjust;

  awb_extended_outdoor_exp_trigger_type  awb_extended_outdoor_exp_trigger;

}awb_extended_outdoor_heuristic_type;




typedef struct{

  int                        awb_single_color_heuristic_enable;
  awb_single_color_type        awb_single_color_detect[NUM_SPECIAL_COLOR_DETECT];

}awb_single_color_tracking_type;





typedef struct{

    awb_trigger_type_int      awb_day_sum_threshold_count;
    awb_trigger_type_int      awb_flo_sum_threshold_count;
    awb_misleading_zone_type  awb_misleading_color_zones[MISLEADING_COLOR_ZONE_NUM];

}awb_misleading_zone_process_type;




typedef struct{

  int                           green_proj;
  int                         green_offset_bg;
  int                         green_rg_offset_top_H ;
  int                         green_rg_offset_bottom_H ;
  float                       slope_factor_m;
  float                       slope_factor_m_shade;
  int                         awb_cw_green_reject_threshold ;
  int                         awb_custom_fl_green_reject_threshold;
  int                         bright_green_percentage;
  int                         dark_green_percentage;
  int                         green_enhance_low_pec;
  int                         green_enhance_high_pec;
  int                         green2f_outlier_dist2;

  chromatix_awb_gain_adj_type green_enhance_gain_adjust_high;
  awb_misleading_zone_type    green_zone_assist[GREEN_ZONE_ASSIST_NUM];

  trigger_point_type          bright_green_exp_index;
  trigger_point_type          shade_green_exp_index;

  int                         exp_weight;

}awb_green_struct_type;


typedef struct{
  int   warmup_enable_aa;
  int   warmup_enable_hh;
  float weight_reference_aa;
  float weight_reference_ah;
  float weight_reference_hh;

}awb_weight_lowlight_warm_type;



typedef struct{

  float a_h_line_boundary;
  float day_f_line_boundary;
  float d75_d65_line_boundary;
  float d65_d50_line_boundary;
  float d65_d50_shifted_line_boundary;
  float f_a_line_boundary;
  float cw_tl84_line_boundary;
  float d50_weighted_sample_boundary;
  float d65_weighted_sample_boundary;

}awb_decision_boundary_type;



#define HEURISTIC_WEIGHT_NUM 20
typedef struct{
    float exp_weight_low[2];
    float exp_weight_high[2];
    float cct_weight_low[2];
    float cct_weight_high[2];
}awb_heuristic_weight_type;




typedef struct{

  int                           awb_pre_flash_enable;
  int                           awb_flash_stat_sat_threshold;
  int                           awb_preflash_outlier_distance;
  int                           awb_preflash_outlier_distance_no_flash;

  chromatix_awb_reference_type  awb_mainflash_typ_ref;
  chromatix_awb_reference_type  awb_preFlash_min_ref;
  chromatix_awb_reference_type  awb_preFlash_max_ref;
  chromatix_awb_reference_type  awb_mainflash_min_ref;
  chromatix_awb_reference_type  awb_mainflash_max_ref;

  int                           awb_flash_valid_sample_high_threshold;
  int                           awb_flash_valid_sample_low_threshold;

  trigger_point_type            awb_flash_typ_decision_rg_offset;
  trigger_point_type            awb_flash_typ_decision_bg_offset;

  chromatix_awb_gain_adj_type   awb_flash_corner_sample_ref_adjust;
  awb_flash_lut_info            awb_flash_lut[AWB_FLASH_ADJUST_LUT];

}awb_preflash_type;


typedef struct{
    int awb_front_camera;
    int awb_cap_gain_enable;
    int awb_fd_awb_enable;
}awb_front_camera_ctrl_type;

#define AWB_RESERVED_PARAM 50

//Reserve values all set to 0
typedef struct{

    int   reserved_int[AWB_RESERVED_PARAM];
    float reserved_float[AWB_RESERVED_PARAM];

}awb_reserved_data_type;


/******************************************************************************/
// Feature name:awb_algo_structure
// All tuning parameter definitions for AWB algorithm
/******************************************************************************/
typedef struct{

 awb_basic_tuning_type               awb_basic_tuning;                //basic tuning parameters
 awb_weight_vector_type              awb_weight_vector;               //awb weight vectors including illuminant and distance weight vectors
 awb_green_struct_type               awb_green_zone_param;            //green zones and mapping parameters
 awb_dark_threshold_type             awb_dark_threshold;              //Thresholds for rejecting dark stats
 awb_temporal_tuning_type            awb_temporal_tuning;             //temporal heuristic parameters
 awb_heuristic_control_type          awb_heuristic_control;           //heuristic control parameters
 awb_heuristic_weight_type              awb_heuristic_weight[HEURISTIC_WEIGHT_NUM]; //Decision weights for heuristic functions
 awb_white_world_struct_type         awb_white_world;                 //White world decision parameters
 awb_decision_boundary_type          awb_decision_boundary;           //awb decision boundaries
 awb_cluster_tuning_type             awb_clusters_tuning;             //cluster control parameters
 awb_weight_lowlight_warm_type       awb_weight_lowlight_warm;        //A and Horizon lights warming parameters
 awb_CCM_type                        awb_CCM_control;                 //AWB driven CCM parameter
 awb_preflash_type                   awb_preFlash_param;              //AWB preflash tuning parameters
 awb_led_tuning_type                 awb_led_tuning;                  //LED tuning (excluding preFlash)
 awb_extended_outdoor_heuristic_type awb_extended_outdoor_heuristic;  //awb outdoor heuristics with extended tuning parameters
 awb_single_color_tracking_type      awb_single_color_tracking;       //single color tracking parameters
 awb_misleading_zone_process_type    awb_misleading_color_zone;       //misleading color zone
 awb_golden_module_info_type         awb_golden_module_info;          //golden module information
 awb_flow_control_type                 awb_flow_control;                  //awb flow control parameters
 awb_blue_tuning_type                awb_blue_tuning;                 //blue color tuning (sky, snow blue, and beach blue)
 awb_skin_control_type               awb_skin_control;                //skin color control
 awb_aux_sensor_type                 awb_aux_sensor;                  //auxiliary sensor control
 awb_front_camera_ctrl_type             awb_front_camera_control;        //Front camera control parameters
 awb_MWB_type                        awb_MWB;                         //Manual White Balance parameters
 awb_reserved_data_type              awb_reserved_data;               //reserved data

}awb_algo_struct_type;



/******************************************************************************
    AEC tuning structures
******************************************************************************/

#define NUM_AEC_STATS              16
#define MAX_EXPOSURE_TABLE_SIZE    700
#define MAX_SNAPSHOT_LUT_SIZE      10
#define MAX_AEC_TRIGGER_ZONE       6

typedef struct
{
    unsigned short gain;                        // Gain
    unsigned int   line_count;                  // LineCt
} exposure_entry_type;


typedef struct
{
    unsigned short valid_entries;                                   // Number of entries in the exposure table with digital EV feature disabled
    int aec_enable_digital_gain_for_EV_lowlight;                    // Flag to enable\disable the digital EV feature
    unsigned short total_entries_with_digital_gain_for_EV;          // Number of entries in the exposure table with digital EV feature enabled
    unsigned short fix_fps_aec_table_index;                         // Index upto which the frame rate is fixed (linear AFR kicks in beyond this point)
    exposure_entry_type exposure_entries[MAX_EXPOSURE_TABLE_SIZE];  // Exposure table with gain and line count entries
} aec_exposure_table_type;

/**
 * Lux trigger definition
 */
typedef struct {
  int start;
  int end;
} aec_lux_trigger_type;

typedef enum {
  BAYER_CHNL_R,
  BAYER_CHNL_G,
  BAYER_CHNL_B,
  BAYER_CHNL_MAX
} aec_bayer_channel_type;

/**
 * Luma target tuning
 */
typedef struct {
  unsigned int           luma_target;           // Luma target
} aec_luma_target_triggered_type;


typedef struct
{
    int                             num_zones;                                  // Number of zones actually used
    aec_lux_trigger_type            triggers[MAX_AEC_TRIGGER_ZONE-1];           // Trigger point to enter the next zone
    aec_luma_target_triggered_type  triggered_params[MAX_AEC_TRIGGER_ZONE];     // Parameters that can be tuned per-zone
} aec_luma_target_type;

/**
 * This structure defines the metering tables
 */
typedef struct
{
    float    AEC_weight_center_weighted[NUM_AEC_STATS][NUM_AEC_STATS];          // Center-weighted metering table (0x304)
    float    AEC_weight_spot_metering[NUM_AEC_STATS][NUM_AEC_STATS];            // Spot-metering table (0x304)
} aec_metering_table_type;


typedef struct
{
    unsigned int    aec_start_index;                        // Exposure index to be used upon camera startup
    unsigned short  luma_tolerance;                         // Tolerance range to deem AEC as settled
    int             frame_skip_startup;                     // Frame skip value to be used upon camera startup
    float           aggressiveness_startup;                 // Aggressiveness value to use upon camera startup
    float           exposure_index_adj_step;                // Exposure step size (0x304)
    float           ISO100_gain;                            // ISO 100 gain value (0x304)
    int             antibanding_vs_ISO_priority;            // In manual ISO, whether anti-banding or ISO takes priority
    float           max_snapshot_exposure_time_allowed;     // Maximum snapshot exposure time (in seconds) (0x304)
    float           reserved[50];                           // Reserved for temporary use
} aec_generic_tuning_type;

/**
 * This structure defines the motion ISO tuning parameters
 */
typedef struct
{
    int       motion_iso_enable;           // Flag to enable\disable the motion ISO feature
    float     motion_iso_aggressiveness;   // Motion ISO aggressiveness
    float     motion_iso_threshold;        // Threshold value for the motion ISO compensation to kick in
    float     motion_iso_max_gain;         // Maximum gain that can be used for the motion ISO feature
} aec_motion_iso_type;

/**
 * This structure defines the gain tradeoff and maximum exposure time entries for the snapshot look-up table (LUT)
 */
typedef struct
{
    unsigned short      lux_index;        // Lux index corresponding to each entry
    float             gain_trade_off;   // Gain tradeoff value
    float             max_exp_time;     // Maximum exposure time value (in seconds)
} snapshot_trade_off_table_type;

/**
 * This structure defines the the snapshot look-up table (LUT)
 */
typedef struct
{
    int enable;                                                               // Flag to enable\disable the snapshot LUT feature
    int exposure_stretch_enable;                                              // Flag to enable\disable the exposure stretch feature
    unsigned char valid_entries;                                              // Number of valid entries in the snapshot LUT
    snapshot_trade_off_table_type snapshot_ae_table[MAX_SNAPSHOT_LUT_SIZE];   // Snapshot look-up table (LUT)
} aec_snapshot_exposure_type;



typedef struct
{
    // For general flash and LED tuning
    unsigned short   wled_trigger_idx;              // Lux index above which flash is fired in the AUTO mode
    float            aec_led_pre_flux;              // Pre-flash/torch flux value
    float            aec_led_flux_hi;               // High power LED flux value
    float            aec_led_flux_med;              // Medium power LED flux value
    float            aec_led_flux_low;              // Low power LED flux value

    int              smart_flash_est_enable;        // Enable smart LED estimation for AEC
    float            smart_flash_est_strength;      // Amount of flexibility/strength allowed for smart LED (0-1)
    int              smart_flash_est_awb_enable;    // Enable smart LED estimation also for manual AWB
    float            smart_flash_est_awb_strength;  // Amount of flexibility/strength allowed for AWB smart LED (0-1)

    int              flash_target;                  // Luma target for flash (set to -1 to use lux-based target)
    float            target_interp_k_start;         // Below this k value, current luma target is used for flash
    float            target_interp_k_end;           // Above this k value, flash target will be used

    int              smart_flash_target_enable;     // Enable smart decision of luma target (Target may increase)
    int              max_target_offset;             // Maximum allowed for the luma target to increase

    float            reserved[15];                  // Reserved for internal algorithm
} aec_flash_tuning_type;

/**
 * This structure defines the touch AEC tuning parameters (0x304)
 */
typedef struct
{
    int     touch_roi_enable;       // Flag to enable\disable the touch AEC feature
    float   touch_roi_weight;       // Determines the influence of the touched region frame luma value on the overall frame luma calculation
    float   reserved[5];            // Reserved for algo internally
} aec_touch_type;

/**
 * This structure defines the face detection AEC tuning parameters (0x304: AEC_face_priority_type)
 */
/*
...tool team, the defaults are the same for the first 10 entries of the reserved[15] as in 304 header, for the last 5, just set them to 0 as defaults
*/
typedef struct
{
    int     aec_face_enable;         // Flag to enable\disable the face detection AEC feature
    float   aec_face_weight;         // Determines the influence of the face frame luma value on the overall frame luma calculation
    float   reserved[15];            // Reserved for algo internally
} aec_face_priority_type;


typedef struct
{
    int     frame_skip;           // Number of frames skipped between each exposure update
    float   aggressiveness;       // Aggressivenes value which moving from a dark scene to a bright scene
    float   reserved[10];         // Reserved for algo internally
} aec_fast_conv_type;



typedef struct
{
    int     slow_convergence_enable;   // Flag to enable slow convergence for video
    int     frame_skip;                // Number of frames skipped between each exposure update
    float   conv_speed;                // Convergence speed    (0-1)
    int     ht_enable;                 // Flag to enable\disable the holding time logic
    int     ht_luma_tolerance;         // Luma tolerance for holding time reset
    float   ht_thres;                  // Holding time activation threshold for luma settle (in seconds)
    float   ht_max;                    // Maximum amount of holding time allowed (in seconds)
    int     ht_gyro_enable;            // Enable to use gyro for shortening holding time
    float   reserved[25];              // Reserved for algo internally
} aec_slow_conv_type;

/**
 * Bright region tuning parameters
 */
typedef struct
{
    unsigned int          bright_region_thres;  // Threshold for a region to be considered a bright region (Q8)
    float                 bright_weight;        // Weight to increase or decrease the influence of bright regions
} aec_bright_region_triggered_type;



typedef struct
{
  int                                bright_region_enable;                    // Flag to enable\disable the bright region feature
  int                                num_zones;                               // Number of zones actually used
  aec_lux_trigger_type               triggers[MAX_AEC_TRIGGER_ZONE-1];        // Trigger point to enter the next zone
  aec_bright_region_triggered_type   triggered_params[MAX_AEC_TRIGGER_ZONE];  // Parameters that can be tuned per-zone
  float                              min_tweight;                             // Minimal bias table weight for a stats to be included
  float                              max_bright_pct;                          // Maximum number of bright regions to be counted
} aec_bright_region_type;

/**
 * Dark region tuning parameters
 */

typedef struct
{
    unsigned int          dark_region_low_thres;  // Below this threshold means it is dark (Q8)
    unsigned int          dark_region_high_thres; // Above this threshold means it is not dark (Q8)
    float                 dark_weight;            // Weight to increase or decrease the influence of dark region
} aec_dark_region_triggered_type;

typedef struct
{
  int                              dark_region_enable;                        // Flag to enable\disable the dark region feature
  int                              num_zones;                                 // Number of zones actually used
  aec_lux_trigger_type             triggers[MAX_AEC_TRIGGER_ZONE-1];          // Trigger point to enter the next zone
  aec_dark_region_triggered_type   triggered_params[MAX_AEC_TRIGGER_ZONE];    // Parameters that can be tuned per-zone
  float                            min_tweight;                               // Minimal bias table weight for a stats to be include
  float                            max_dark_pct;                              // Maximum number of dark regions to be counted
} aec_dark_region_type;

/**
 * This structure defines the AEC extreme color tuning parameters
 */

typedef struct
{
    float                             adj_ratio[BAYER_CHNL_MAX];              // adjust ratios for all channels
} aec_extreme_color_triggered_type;

typedef struct
{
    int                               extreme_color_enable;                   // Flag to enable\disable the extreme colour feature
    int                               num_zones;                              // Number of zones actually used
    aec_lux_trigger_type              triggers[MAX_AEC_TRIGGER_ZONE-1];       // Trigger point to enter the next zone
    aec_extreme_color_triggered_type  triggered_params[MAX_AEC_TRIGGER_ZONE]; // Parameters that can be tuned per-zone

    float                             red_th;                                 // Extreme red threshold of r/g ratio
    float                             red_interp_pct;                         // Extreme red thresh interpolation range
    float                             green_rg_th;                            // Extreme green threshold of r/g ratio
    float                             green_rg_interp_pct;                    // Extreme green r/g thresh interpolation range
    float                             green_bg_th;                            // Extreme green threshold of b/g ratio
    float                             green_bg_interp_pct;                    // Extreme green b/g thresh interpolation range
    float                             green_cntr_th;                          // Extreme green thresh for the distance to (1,1) on (r/g)&(b/g) domain
    float                             green_cntr_interp_pct;                  // Extreme green center thresh interpolation range
    float                             blue_th;                                // Threshold for extreme blue detection
    float                             blue_interp_pct;                        // Extreme blue thresh interpolation range

    float                             luma_high_th;                           // High threshold for region luma
    float                             luma_low_th;                            // Low threshold for region luma
    float                             color_stats_pct_high_th;                // High threshold for percentage of extreme color stats
    float                             color_stats_pct_low_th;                 // Low threshold for percentage of extreme color stats
    float                             reserved[10];                           // Reserved for internal algorithm use
} aec_extreme_color_type;


typedef struct
{
    /* Flat scene detection tuning */
    int     hist_flat_detector_enable;   // Flag to enable\disable the histogram based flat scene detection feature
    int     start_level;                 // Starting point for the histogram peak detection
    int     end_level;                   // Ending point for the histogram peak detection
    int     range;                       // Range for the histogram peak detection
    float   delta_th_low;                // Low threshold value for peak detection
    float   delta_th_high;               // High threshold value for peak detection
    float   bright_flat_det_th;          // Threshold value for bright flat scene detection
    float   dark_flat_det_th;            // Threshold value for dark flat scene detection
    float   bright_flat_tail_det;        // Threshold value for tail detection for bright flat scenes
    float   dark_flat_tail_det;          // Threshold value for tail detection for dark flat scenes
    /* Flat scene compensation tuning */
    int      bright_flat_compensation_enable;      // Flag to enable\disable the bright flat scene compensation
    int      dark_flat_compensation_enable;        // Flag to enable\disable the dark flat scene compensation
    float    flat_white_grey_vs_nongrey_th;        // Threshold to determine if flat area is brighter than colored regions
    float    flat_dark_grey_vs_nongrey_th;         // Threshold to determine if flat area is darker than colored regions
    float    near_grey_tolerance;                  // Regions with R/G and B/G within the tolerance percentage are considered grey regions
    float    bright_flat_compensation_ratio;       // Ratio for the bright flat scene compensation
    float    dark_flat_compensation_ratio;         // Ratio for the dark flat scene compensation
    int      flat_indoor_disable_start_idx;        // Above this index, flat compensation start to get disabled
    int      flat_indoor_disable_end_idx;          // Above this index, flat compensation fully disabled
} aec_flat_scene_type;

/**
 * This structure defines the histogram based AEC metering parameters
 * default & range values described in aec_hist_metering_type.
 */
typedef struct
{
    float                 max_target_adjust_ratio;       // Maximum target adjust allowed
    float                 min_target_adjust_ratio;       // Minimum target adjust allowed
    unsigned short        sat_low_ref;                   // Low reference/control point for saturation
    unsigned short        sat_high_ref;                  // High reference/control point for saturation
    unsigned short        dark_low_ref;                  // Low reference/control point for darkness
    unsigned short        dark_high_ref;                 // High reference/control point for darkness
} aec_hist_metering_triggered_type;



typedef struct
{
    int                                hist_metering_enable;                       // Flag to enable histogram based AEC metering
    int                                num_zones;                                  // Number of zones actually used
    aec_lux_trigger_type               triggers[MAX_AEC_TRIGGER_ZONE-1];           // Trigger point to enter the next zone
    aec_hist_metering_triggered_type   triggered_params[MAX_AEC_TRIGGER_ZONE];     // Parameters that can be tuned per-zone
    float                              hist_sat_pct[BAYER_CHNL_MAX];               // Percentage of bright pixels used in determine saturation
    float                              hist_dark_pct[BAYER_CHNL_MAX];              // Percentage of dark pixels used to determine darkness
    float                              target_filter_factor;                       // Temporal filter for stability
    float                              reserved[10];                               // Reserved for internal algorithm use
} aec_hist_metering_type;



typedef struct
{
    aec_lux_trigger_type  hdr_indoor_trigger;            // For toggling exposure ratio
    float                 reserved[10];                  // Reserved for algo expansion
} aec_hdr_tuning_type;

/**
 * Automatic Dynamic Range Compression (ADRC) related parameters:
 */

typedef enum
{
    ADRC_MODE_DISABLE = 0,
    ADRC_MODE_GLOBAL,    // Global tone mapping flavor
    ADRC_MODE_LOCAL,    // Local tone mapping flavor (Recommended)
} aec_adrc_mode_type;


typedef struct
{
    aec_adrc_mode_type            mode;                // Default = ADRC_MODE_DISABLE
    aec_hist_metering_type      hist_metering;      // Histogram AEC tuned for ADRC feature
    float                         max_drc_gain;        // Maximal DRC gain at extreme scenes. Default = 4
   float                        reserved[40];       // For internal algorithm use
} aec_adrc_type;

/**
 * This structure defines the tuning parameters input to the AEC algorithm.
 */
typedef struct
{
    aec_generic_tuning_type     aec_generic;                                     // Generic AEC tuning parameters

    aec_exposure_table_type     aec_exposure_table;                              // Exposure table

    aec_snapshot_exposure_type  aec_snapshot_lut;                                // Snapshot look-up table (LUT) tuning parameters

    aec_luma_target_type        aec_luma_target;                                 // Defines the various luma targets

    aec_metering_table_type     aec_metering_tables;                             // Metering tables (center-weighted\spot-metering)

    aec_fast_conv_type          aec_fast_convergence;                            // Fast convergence tuning parameters

    aec_slow_conv_type          aec_slow_convergence;                            // Slow convergence tuning parameters

    aec_flash_tuning_type       aec_led_flash;                                   // AEC LED flash tuning parameters

    aec_touch_type              aec_touch;                                       // Touch AEC tuning parameters

    aec_face_priority_type      aec_face_detection;                              // Face detection AEC tuning parameters

    aec_bright_region_type      aec_bright_region;                               // Bright region tuning parameters

    aec_dark_region_type        aec_dark_region;                                 // Dark region tuning parameters

    aec_extreme_color_type      aec_extreme_color;                               // Extreme colour tuning parameters

    aec_flat_scene_type         aec_flat_scene;                                  // Flat scene tuning parameters

    aec_hist_metering_type      aec_hist_metering;                               // Histogram based metering tuning parameters

    aec_hdr_tuning_type         aec_hdr;                                         // HDR AEC tuning parameters

    aec_adrc_type               aec_adrc;                                        // ADRC tuning parameters

    aec_motion_iso_type         aec_preview_motion_iso;                          // Preview motion ISO tuning parameters

    aec_motion_iso_type         aec_snapshot_motion_iso;                         // Snapshot motion ISO tuning parameters

} AEC_algo_struct_type;

/******************************************************************************
    ASD struct
******************************************************************************/
typedef struct
{
    int ASD_Software_Type; // 0 means hybrid, 1 means using bayer stats, for UA code only
    snow_scene_detect_type snow_scene_detect; //added aggressiveness
    backlit_scene_detect_type backlit_scene_detect; //added aggressiveness , added max_percent_threshold

    landscape_scene_detect_type landscape_scene_detect;
    portrait_scene_detect_type portrait_scene_detect;

    auto_hdr_detect_type auto_hdr_detect;

    hazy_scene_detect_type hazy_scene_detect;

    // moved to ASD from VFE section
    // chromatix_color_conversion_type        sunset_color_conversion;                   // Sunset
    // chromatix_color_conversion_type        skintone_color_conversion;                 // SkinTL84
    // chromatix_color_conversion_type        skintone_color_conversion_d65;             // SkinD65
    // chromatix_color_conversion_type        skintone_color_conversion_a;               // SkinA
} AAA_ASD_struct_type;


/******************************************************************************
Auto Flicker Detection data types
******************************************************************************/
typedef struct
{
    int AFD_continuous_enable;
    float  std_threshold;                             // StdThresh
    unsigned char  percent_threshold;                         // PctThresh
    unsigned long diff_threshold;                            // DiffThresh
    unsigned long frame_ct_threshold;                        // FrameCtThresh
    unsigned char  num_frames;                                //204,  default 6
    unsigned char  frame_skip;                                //204 , default 1
    unsigned long num_rows;                                  //204 , default 480
    unsigned char  num_frames_settle;                            //205, default 3
    unsigned char num_peaks_threshold; //default 6
    float INTL_adj_factor; //0 to 0.45, default 0.25,how much INTL has to be away from band gap.
    int start_antbanding_table; //default 60, 50 or 60
    float max_exp_time_ms; //max exp time we still do AFD, in ms, default 66

    // static band detection
    int thldLevel2Ratio;  // energy ratio threshold of level 2 processing, default 0.97f*Q8
    int thldLevel3Ratio;  // energy ratio threshold of level 3 processing, default 0.95f*Q8
    int thldEkL;          // lower energy threshold of k_th level processing, default 6.4f*Q10
    int thldEkU;          // energy upper threshold of k_th level processing, default 128.0f*Q10
    int thldCounterL3; // positive frame counter threshold for level 3 detection
    int thldCounterL2; // positive frame counter threshold for level 2 detection
    int LevelDepth; // processing level2

} chromatix_auto_flicker_detection_data_type;
/******************************************************************************
******************************************************************************
    AF related params start
 ******************************************************************************
 ******************************************************************************/
#define MAX_AF_KERNEL_NUM 2
#define MAX_HPF_2x5_BUFF_SIZE           10
#define MAX_HPF_2x11_BUFF_SIZE          22
#define FILTER_SW_LENGTH_FIR            11
#define FILTER_SW_LENGTH_IIR            6
#define MAX_ACT_MOD_NAME_SIZE           32
#define MAX_ACT_NAME_SIZE               32

#define AF_PD_MAX_NUM_ROI               10
#define AF_PD_MAX_TABLE_ENTRIES         20
/* BAF related macro */
#define MAX_BAF_GAMMA_Y_ENTRY           3
#define MAX_BAF_GAMMA_LUT_ENTRY         32
#define MAX_BAF_FIR_ENTRY               13
#define MAX_BAF_IIR_ENTRY               10
#define MAX_BAF_CORING_ENTRY            17
#define MAX_BAF_FILTER                  3
#define MAX_BAF_FILTER_2ND_TIER         2
#define MAX_BAF_ROI_NUM                 282

///*****************************
//af_algo_type: Type of algorithm currently supported
///*****************************
typedef enum _af_algo_type{
  AF_PROCESS_DEFAULT   = -2,
  AF_PROCESS_UNCHANGED = -1,
  AF_EXHAUSTIVE_SEARCH = 0,
  AF_EXHAUSTIVE_FAST,
  AF_HILL_CLIMBING_CONSERVATIVE,
  AF_HILL_CLIMBING_DEFAULT,
  AF_HILL_CLIMBING_AGGRESSIVE,
  AF_FULL_SWEEP,
  AF_SLOPE_PREDICTIVE_SEARCH,
  AF_CONTINUOUS_SEARCH,
  AF_PROCESS_MAX
} af_algo_type;

///*****************************
//single_index_t: Enum for indexing mapping for distance to
//lens position
///*****************************
typedef enum _single_index_t {
  SINGLE_NEAR_LIMIT_IDX    = 0,
  SINGLE_7CM_IDX           = 1,
  SINGLE_10CM_IDX          = 2,
  SINGLE_14CM_IDX          = 3,
  SINGLE_20CM_IDX          = 4,
  SINGLE_30CM_IDX          = 5,
  SINGLE_40CM_IDX          = 6,
  SINGLE_50CM_IDX          = 7,
  SINGLE_60CM_IDX          = 8,
  SINGLE_120CM_IDX         = 9,
  SINGLE_HYP_F_IDX         = 10,
  SINGLE_INF_LIMIT_IDX     = 11,
  SINGLE_MAX_IDX           = 12,
}single_index_t; //TODO : Chage to Enum Capital

/**
 * af_cam_name: Enum for camera profile
 **/
typedef enum _af_cam_name {
  ACT_MAIN_CAM_0,
  ACT_MAIN_CAM_1,
  ACT_MAIN_CAM_2,
  ACT_MAIN_CAM_3,
  ACT_MAIN_CAM_4,
  ACT_MAIN_CAM_5,
  ACT_WEB_CAM_0,
  ACT_WEB_CAM_1,
  ACT_WEB_CAM_2,
} af_cam_name;

/**
 * _baf_tuning_preset_enum_t : enum for preset_id
 *
 **/
typedef enum _baf_tuning_preset_enum_t{
  AF_TUNING_CUSTOM                      = -1,
  AF_TUNING_PRESET_0,
  AF_TUNING_PRESET_1,
  AF_TUNING_PRESET_2,
  AF_TUNING_PRESET_3,
  AF_TUNING_PRESET_4,
  AF_TUNING_PRESET_5,
  AF_TUNING_PRESET_MAX
} baf_tuning_preset_enum_t;

/**
 * _baf_roi_pattern_enum_t : enum for ROI pattern type
 *
 **/
typedef enum _baf_roi_pattern_enum_t{
  BAF_ROI_PATTERN_CUSTOM                = -1,
  BAF_ROI_PATTERN_RECT                  = 0,
  BAF_ROI_PATTERN_CROSS,
  BAF_ROI_PATTERN_DIAMOND,
  BAF_ROI_PATTERN_SPARSE,
  BAF_ROI_PATTERN_MAX
} baf_roi_pattern_enum_t;

/**
 * _af_scene_type_enum_t : enum for AF scene type
 *
 **/
typedef enum _af_scene_type_enum_t {
  AF_SCENE_TYPE_NORMAL                  = 0,
  AF_SCENE_TYPE_LOWLIGHT                = 1,
  AF_SCENE_TYPE_FACE                    = 2,
  AF_SCENE_TYPE_MAX,
} af_scene_type_enum_t;

/**
 * af_tuning_fdac_type: Enum for indexing mapping for collected DAC for
 *   face forward/up/down
 **/
typedef enum _af_tuning_fdac_type {
  AF_TUNING_DAC_FACE_FORWARD            = 0,
  AF_TUNING_DAC_FACE_UP,
  AF_TUNING_DAC_FACE_DOWN,
  AF_TUNING_DAC_MAX
} af_tuning_fdac_type;

/**
 * ACTUATOR_TYPE: Enum for Type of actuator, which impacts core algo behaviors
 **/
typedef enum _ACTUATOR_TYPE {
  ACT_TYPE_CLOSELOOP                    = 0,
  ACT_TYPE_OPENLOOP,
  ACT_TYPE_MAX,
} ACTUATOR_TYPE;

/**
* _e_AF_FV_STATS_TYPE: Enum for Type of Stats
 **/
typedef enum _e_AF_FV_STATS_TYPE {
  AF_FV_STATS_TYPE_HW_1                 = 0,
  AF_FV_STATS_TYPE_HW_2                 = 1,
  AF_FV_STATS_TYPE_SW                   = 2,
  AF_FV_STATS_TYPE_MAX                  = 3,
} AF_FV_STATS_TYPE;

/**
 * _af_haf_algo_enum_type: Enum for HAF algorithm types
 *
 *    @AF_HAF_ALGO_TOF: TOF algo
 *    @AF_HAF_ALGO_PDAF: PDAF algo
 *    @AF_HAF_ALGO_DCIAF: DCIAF algo
 *    @AF_HAF_ALGO_DBG: Debug Algo
 **/
typedef enum {
  AF_HAF_ALGO_TOF                       = 0,
  AF_HAF_ALGO_PDAF,
  AF_HAF_ALGO_DCIAF,
  AF_HAF_ALGO_DBG,
  AF_HAF_ALGO_MAX,
} af_haf_algo_enum_type;

/**
 * _AF_CAM_ORIENTATION_TYPE: Direction of Aux wrt Main Camera
 *
 *    @AF_CAM_ORIENT_LEFT: Towards left
 *    @AF_CAM_ORIENT_RIGHT: Towards right
 *    @AF_CAM_ORIENT_UP: Towards up
 *    @AF_CAM_ORIENT_DOWN: Towards down
 **/
typedef enum _AF_CAM_ORIENTATION_TYPE{
  AF_CAM_ORIENT_LEFT                  = 0,
  AF_CAM_ORIENT_RIGHT,
  AF_CAM_ORIENT_UP,
  AF_CAM_ORIENT_DOWN,
  AF_CAM_ORIENT_MAX,
} AF_CAM_ORIENTATION_TYPE;


typedef struct _step_size_t {
  unsigned short rgn_0; /* reserved */
  unsigned short rgn_1;
  unsigned short rgn_2;
  unsigned short rgn_3;
  unsigned short rgn_4; /* reserved */
}step_size_t;


typedef struct _step_size_table_t {
  step_size_t    Prescan_normal_light;
  step_size_t    Prescan_low_light;
  step_size_t    Finescan_normal_light;
  step_size_t    Finescan_low_light;
}step_size_table_t;


typedef struct _BV_threshold_t {
  float thres[8]; /* CUR_BV_INFO */ /* 0, 20, 50, 100, 400, 700, OUTDOOR_, Sky */
}BV_threshold_t;


typedef struct _single_threshold_t {
  float flat_inc_thres;
  float flat_dec_thres;
  float macro_thres;
  float drop_thres;
  unsigned long int hist_dec_dec_thres;
  unsigned long int hist_inc_dec_thres;
  BV_threshold_t dec_dec_3frame;
  BV_threshold_t inc_dec_3frame;
  BV_threshold_t dec_dec;
  BV_threshold_t dec_dec_noise;
  BV_threshold_t inc_dec;
  BV_threshold_t inc_dec_noise;
  BV_threshold_t flat_threshold;
}single_threshold_t;


typedef struct _FVscore_threshold_t {
  int                                   default_stats;
  BV_threshold_t                        score_ratio_showdif;
  float                                 strict_noise;
  float                                 normal_noise;
  float                                 light_noise;
  int                                   strong_peak_thres;
  int                                   strong_inc_thres;
  int                                   strong_dec_thres;
}FVscore_threshold_t;


typedef struct _single_optic_t {
  unsigned short CAF_far_end;
  unsigned short CAF_near_end;
  unsigned short TAF_far_end;
  unsigned short TAF_near_end;
  unsigned short srch_rgn_1;
  unsigned short srch_rgn_2;
  unsigned short srch_rgn_3;
  unsigned short fine_srch_rgn;
  unsigned short far_zone;
  unsigned short near_zone;
  unsigned short mid_zone;
  unsigned short far_start_pos;
  unsigned short near_start_pos;
  unsigned short init_pos;
}single_optic_t;



typedef struct _af_tuning_single_t {
  unsigned short       index[SINGLE_MAX_IDX]; /* single_index_t */
  unsigned short       actuator_type;         /* ACTUATOR_TYPE */
  unsigned short       is_hys_comp_needed;
  unsigned short       step_index_per_um;
  step_size_table_t    TAF_step_table;
  step_size_table_t    CAF_step_table;
  unsigned short       PAAF_enable;
  single_threshold_t   sw;
  single_threshold_t   hw;
  float                BV_gain[8];            /* CUR_BV_INFO */
  single_optic_t       optics;
  FVscore_threshold_t  score_thresh;
}af_tuning_single_t;


typedef struct _af_tuning_sp {
  float fv_curve_flat_threshold;
  float slope_threshold1;
  float slope_threshold2;
  float slope_threshold3;
  float slope_threshold4;
  unsigned int lens_pos_0;
  unsigned int lens_pos_1;
  unsigned int lens_pos_2;
  unsigned int lens_pos_3;
  unsigned int lens_pos_4;
  unsigned int lens_pos_5;
  unsigned int base_frame_delay;
  int downhill_allowance;
  int downhill_allowance_1;
} af_tuning_sp_t;


typedef struct _af_tuning_gyro {
  unsigned char         enable;
  float                 min_movement_threshold;
  float                 stable_detected_threshold;
  unsigned short        unstable_count_th;
  unsigned short        stable_count_th;
  float                 fast_pan_threshold;
  float                 slow_pan_threshold;
  unsigned short        fast_pan_count_threshold;
  unsigned short        sum_return_to_orig_pos_threshold;
  unsigned short        stable_count_delay;
} af_tuning_gyro_t;



typedef struct _af_tuning_lens_sag_comp {
  unsigned char                         enable;
  unsigned int                          f_dac[AF_TUNING_DAC_MAX];
  float                                 f_dist;
  float                                 trigger_threshold;
} af_tuning_lens_sag_comp_t;


typedef struct _af_tuning_pd_roi_config_t {
  int                                   roi_loc_y;
  int                                   roi_loc_x;
  int                                   roi_num_rows;
  int                                   roi_num_cols;
} af_tuning_pd_roi_config_t;


typedef struct _af_tuning_pd_roi_t {
  int                                   num_entries;
  af_tuning_pd_roi_config_t             config[AF_PD_MAX_NUM_ROI];
} af_tuning_pd_roi_t;


typedef struct _af_tuning_pd_noise_tbl_entry_t {
  float                                 noise_gain;
  float                                 multiplier;
} af_tuning_pd_noise_tbl_entry_t;


typedef struct _af_tuning_pd_conf_tbl_entry_t {
  float                                 noise_gain;
  int                                   min_conf;
} af_tuning_pd_conf_tbl_entry_t;


typedef struct _af_tuning_pd_stable_tbl_entry_t {
  int                                   fps;
  int                                   min_stable_cnt;
} af_tuning_pd_stable_tbl_entry_t;


typedef struct _af_tuning_pd_focus_tbl_entry_t{
  int                                   defocus;
  float                                 move_pcnt;
} af_tuning_pd_focus_tbl_entry_t;


typedef struct _af_tuning_pd_noise_tbl_t {
  int                                   num_entries;
  af_tuning_pd_noise_tbl_entry_t        entries[AF_PD_MAX_TABLE_ENTRIES];
} af_tuning_pd_noise_tbl_t;


typedef struct _af_tuning_pd_conf_tbl_t {
  int                                   num_entries;
  af_tuning_pd_conf_tbl_entry_t         entries[AF_PD_MAX_TABLE_ENTRIES];
} af_tuning_pd_conf_tbl_t;


typedef struct _af_tuning_pd_focus_tbl_t {
  int                                   num_entries;
  af_tuning_pd_focus_tbl_entry_t        entries[AF_PD_MAX_TABLE_ENTRIES];
} af_tuning_pd_focus_tbl_t;


typedef struct _af_tuning_pd_stable_tbl_t {
  int                                   num_entries;
  af_tuning_pd_stable_tbl_entry_t       entries[AF_PD_MAX_TABLE_ENTRIES];
} af_tuning_pd_stable_tbl_t;


typedef struct _af_tuning_pd_focus_scan_t {
  int                                   focus_conv_frame_skip;
  int                                   enable_fine_scan;
  int                                   min_fine_scan_range;
  int                                   fine_scan_step_size;
  int                                   focus_done_threshold;
} af_tuning_pd_focus_scan_t;


typedef struct _af_tuning_pd_monitor_t {
  int                                   wait_after_focus_cnt;
  int                                   wait_conf_recover_cnt;
  float                                 defocused_threshold;
  float                                 depth_stable_threshold;
} af_tuning_pd_monitor_t;


typedef struct _af_tuning_pdaf_t {
  af_tuning_pd_roi_t                    roi;
  af_tuning_pd_focus_tbl_t              focus_tbl;
  af_tuning_pd_noise_tbl_t              noise_tbl;
  af_tuning_pd_conf_tbl_t               conf_tbl;
  af_tuning_pd_stable_tbl_t             stable_tbl;
  af_tuning_pd_focus_scan_t             focus_scan;
  af_tuning_pd_monitor_t                scene_monitor;
  float                                 reserve[200];
} af_tuning_pdaf_t;


typedef struct _af_tuning_dciaf_t {
  unsigned char                         monitor_enable;
  unsigned int                          monitor_freq;
  unsigned int                          search_freq;
  float                                 baseline_mm;
  AF_CAM_ORIENTATION_TYPE               aux_direction;
  float                                 macro_est_limit_cm;
  unsigned char                         alignment_check_enable;
  int                                   jump_to_start_limit;
  int                                   num_near_steps;
  int                                   num_far_steps;
  int                                   dciaf_step_size;
  unsigned char                         motion_data_use_enable;
  int                                   scene_change_lens_pos_th;
  int                                   panning_stable_lens_pos_th;
  int                                   panning_stable_duration_ms_bright;
  int                                   panning_stable_duration_ms_low;
  float                                 reserve[100];
} af_tuning_dciaf_t;


typedef struct _af_tuning_tof_t {
  int                                   lens_laser_dist_comp_mm;
  int                                   wait_frame_limt;
  int                                   max_tof_srch_cnt;
  int                                   jump_to_start_limit;
  int                                   num_near_steps;
  int                                   num_far_steps;
  int                                   tof_step_size;
  int                                   normal_light_cnt;
  int                                   lowlight_cnt;
  int                                   num_monitor_samples;
  int                                   scene_change_distance_thres;
  int                                   scene_change_lens_pos_thres;
  int                                   far_scene_coarse_srch_enable;
  unsigned char                         enable;
  int                                   outdoor_lux_idx;
  float                                 reserve[100];
} af_tuning_tof_t;

typedef struct _af_fine_srch_extension_t {
  int                                  max_fine_srch_extension_cnt;
  int                                  num_near_steps;
  int                                  num_far_steps;
  int                                  step_size;
  float                                decrease_drop_ratio;
} af_fine_srch_extension_t;

typedef struct _af_tuning_haf_t {
  unsigned char                         enable;
  unsigned char                         algo_enable[AF_HAF_ALGO_MAX];
  unsigned char                         stats_consume_enable[AF_FV_STATS_TYPE_MAX];
  char                                  lens_sag_comp_enable;
  char                                  hysteresis_comp_enable;
  int                                   actuator_shift_comp;
  int                                   actuator_hysteresis_comp;
  float                                 actuator_sensitivity;
  AF_FV_STATS_TYPE                      stats_select;
  float                                 fine_srch_drop_thres;
  unsigned int                          fine_step_size;
  unsigned int                          max_move_step;
  unsigned int                          max_move_step_buffer;
  unsigned int                          base_frame_delay;
  af_tuning_pdaf_t                      pdaf;
  af_tuning_tof_t                       tof;
  af_tuning_dciaf_t                     dciaf;
  float                                 reserve[100];
} af_tuning_haf_t;


typedef struct _af_tuning_vbt_t {
  unsigned char                         enable;
  float                                 comp_time;
  float                                 contamination_pcnt_allow;
} af_tuning_vbt_t;


typedef struct _af_tuning_sad {
  unsigned char enable;
  float gain_min;
  float gain_max;
  float ref_gain_min;
  float ref_gain_max;
  unsigned short threshold_min;
  unsigned short threshold_max;
  unsigned short ref_threshold_min;
  unsigned short ref_threshold_max;
  unsigned short frames_to_wait;
} af_tuning_sad_t;


typedef struct _af_tuning_continuous {
  unsigned char enable;
  unsigned char   scene_change_detection_ratio;
  float           panning_stable_fv_change_trigger;
  float           panning_stable_fvavg_to_fv_change_trigger;
  unsigned short  panning_unstable_trigger_cnt;
  unsigned short  panning_stable_trigger_cnt;
  unsigned long   downhill_allowance;
  unsigned short  uphill_allowance;
  unsigned short  base_frame_delay;
  unsigned short  scene_change_luma_threshold;
  unsigned short  luma_settled_threshold;
  float           noise_level_th;
  unsigned short  search_step_size;
  af_algo_type  init_search_type;
  af_algo_type  search_type;
  unsigned short  low_light_wait;
  unsigned short  max_indecision_cnt;
  float           flat_fv_confidence_level;
  af_tuning_sad_t af_sad;
  af_tuning_gyro_t af_gyro;
}af_tuning_continuous_t;


typedef struct _af_tuning_exhaustive {
  unsigned short num_gross_steps_between_stat_points;
  unsigned short num_fine_steps_between_stat_points;
  unsigned short num_fine_search_points;
  unsigned short downhill_allowance;
  unsigned short uphill_allowance;
  unsigned short base_frame_delay;
  unsigned short coarse_frame_delay;
  unsigned short fine_frame_delay;
  unsigned short coarse_to_fine_frame_delay;
  float          noise_level_th;
  float          flat_fv_confidence_level;
  float          climb_ratio_th;
  int            low_light_luma_th;
  int            enable_multiwindow;
  float          gain_thresh;
}af_tuning_exhaustive_t;


typedef struct _af_tuning_fullsweep_t {
  unsigned short num_steps_between_stat_points;
  unsigned short frame_delay_inf;
  unsigned short frame_delay_norm;
  unsigned short frame_delay_final;
}af_tuning_fullsweep_t;


typedef struct _af_shake_resistant {
  unsigned char enable;
  float max_gain;
  unsigned char min_frame_luma;
  float tradeoff_ratio;
  unsigned char toggle_frame_skip;
}af_shake_resistant_t;


typedef struct _af_motion_sensor {
  float af_gyro_trigger;
  float af_accelerometer_trigger;
  float af_magnetometer_trigger;
  float af_dis_motion_vector_trigger;
}af_motion_sensor_t;


typedef struct _af_fd_priority_caf {
  float pos_change_th;
  float pos_stable_th_hi;
  float pos_stable_th_low;
  float size_change_th;
  float old_new_size_diff_th;
  int stable_count_size;
  int stable_count_pos;
  int no_face_wait_th;
  int fps_adjustment_th;
} af_fd_priority_caf_t;


typedef struct _af_tuning_algo {
  af_algo_type af_process_type;
  unsigned short position_near_end;
  unsigned short position_default_in_macro;
  unsigned short position_boundary;
  unsigned short position_default_in_normal;
  unsigned short position_far_end;
  unsigned short position_normal_hyperfocal;
  unsigned short position_macro_rgn;
  unsigned short undershoot_protect;
  unsigned short undershoot_adjust;
  float min_max_ratio_th;
  int led_af_assist_enable;
  long led_af_assist_trigger_idx;
  int lens_reset_frame_skip_cnt;
  float low_light_gain_th;
  float base_delay_adj_th;
  af_tuning_continuous_t af_cont;
  af_tuning_exhaustive_t af_exh;
  af_tuning_fullsweep_t af_full;
  af_tuning_sp_t af_sp;
  af_tuning_single_t af_single;
  af_shake_resistant_t af_shake_resistant;
  af_motion_sensor_t af_motion_sensor;
  af_fd_priority_caf_t fd_prio;
  af_tuning_lens_sag_comp_t             lens_sag_comp;
  af_tuning_haf_t                       af_haf;
  af_tuning_vbt_t                       vbt;
  float                                 reserve[100];
}af_tuning_algo_t;


typedef struct _af_vfe_config {
  unsigned short fv_min;
  unsigned short max_h_num;
  unsigned short max_v_num;
  unsigned short max_block_width;
  unsigned short max_block_height;
  unsigned short min_block_width;
  unsigned short min_block_height;
  float h_offset_ratio_normal_light;
  float v_offset_ratio_normal_light;
  float h_clip_ratio_normal_light;
  float v_clip_ratio_normal_light;
  float h_offset_ratio_low_light;
  float v_offset_ratio_low_light;
  float h_clip_ratio_low_light;
  float v_clip_ratio_low_light;
  float touch_scaling_factor_normal_light;
  float touch_scaling_factor_low_light;
  int bf_scale_factor;
  unsigned short h_num_default;
  unsigned short v_num_default;
} af_vfe_config_t;


typedef struct _af_vfe_legacy_hpf {
  char      a00;
  char      a02;
  char      a04;
  char      a20;
  char      a21;
  char      a22;
  char      a23;
  char      a24;
} af_vfe_legacy_hpf_t;


typedef struct _af_vfe_hpf {
  af_vfe_legacy_hpf_t af_hpf;
  int bf_hpf_2x5[MAX_HPF_2x5_BUFF_SIZE];
  int bf_hpf_2x11[MAX_HPF_2x11_BUFF_SIZE];
} af_vfe_hpf_t;


typedef struct _af_vfe_sw_fir_hpf_t {
  int                    a[FILTER_SW_LENGTH_FIR];
  double                 fv_min_hi;
  double                 fv_min_lo;
  unsigned long int      coeff_length;
} af_vfe_sw_fir_hpf_t;


typedef struct _af_vfe_sw_iir_hpf_t {
  double                 a[FILTER_SW_LENGTH_IIR];
  double                 b[FILTER_SW_LENGTH_IIR];
  double                 fv_min_hi;
  double                 fv_min_lo;
  unsigned long int      coeff_length;
} af_vfe_sw_iir_hpf_t;


typedef struct af_vfe_sw_hpf_t {
  unsigned short         filter_type;    /* af_sw_filter_type */
  af_vfe_sw_fir_hpf_t    fir;
  af_vfe_sw_iir_hpf_t    iir;
} af_vfe_sw_hpf_t;


typedef struct _baf_tuning_gamma_t {
  unsigned char                         ch_sel;
  float                                 Y_coeffs[MAX_BAF_GAMMA_Y_ENTRY];
  unsigned char                         g_sel;
  unsigned char                         LUT_enable;
  int                                   gamma_LUT[MAX_BAF_GAMMA_LUT_ENTRY];
} baf_tuning_gamma_t;


typedef struct _baf_tuning_gamma_param_t {
  baf_tuning_preset_enum_t              preset_id;
  baf_tuning_gamma_t                    gamma_custom;
} baf_tuning_gamma_param_t;


typedef struct _baf_tuning_coring_t {
  unsigned int                          x_index[MAX_BAF_CORING_ENTRY];
  int                                   threshold;
  int                                   gain;
} baf_tuning_coring_t;


typedef struct _baf_tuning_HV_filter_t {
  unsigned char                         fir_en;
  unsigned char                         iir_en;
  int                                   fir[MAX_BAF_FIR_ENTRY];
  float                                 iir[MAX_BAF_IIR_ENTRY];
  int                                   shift_bits;
  unsigned char                         scaler_sel;
} baf_tuning_HV_filter_t;


typedef struct _baf_HV_filter_t {
  baf_tuning_preset_enum_t              preset_id;
  baf_tuning_coring_t                   coring;
  baf_tuning_HV_filter_t                filter_custom;
} baf_HV_filter_t;


typedef struct _baf_tuning_scaler_t {
  int                                   M;
  int                                   N;
} baf_tuning_scaler_t;


typedef struct _baf_tuning_filter_t {
  baf_HV_filter_t                       HV_filter[MAX_BAF_FILTER];
  baf_HV_filter_t                       HV_filter_2nd_tier[MAX_BAF_FILTER_2ND_TIER];
  baf_tuning_scaler_t                   scaler;
} baf_tuning_filter_t;


typedef struct _baf_tuning_roi_t {
  unsigned char                         flag;
  unsigned int                          x;
  unsigned int                          y;
  unsigned int                          width;
  unsigned int                          height;
} baf_tuning_roi_t;


typedef struct _baf_tuning_roi_param_t {
  baf_roi_pattern_enum_t                preset_id;
  float                                 grid_size_h;
  float                                 grid_size_v;
  float                                 grid_gap_h;
  float                                 grid_gap_v;
  int                                   num_ROI;
  baf_tuning_roi_t                      ROI_custom[MAX_BAF_ROI_NUM];
} baf_tuning_roi_param_t;


typedef struct _af_tuning_baf_t {
  baf_tuning_roi_param_t                roi_config[AF_SCENE_TYPE_MAX];
  baf_tuning_gamma_param_t              gamma[AF_SCENE_TYPE_MAX];
  baf_tuning_filter_t                   filter[AF_SCENE_TYPE_MAX];
} af_tuning_baf_t;


typedef struct _af_tuning_vfe {
  unsigned short   fv_metric;
  af_vfe_config_t  config;
  af_vfe_hpf_t     hpf_default;
  af_vfe_hpf_t     hpf_face;
  af_vfe_hpf_t     hpf_low_light;
} af_tuning_vfe_t;


typedef struct _af_tuning_sw_stats {
  af_vfe_sw_hpf_t  sw_hpf_default;
  af_vfe_sw_hpf_t  sw_hpf_face;
  af_vfe_sw_hpf_t  sw_hpf_lowlight;
  float            sw_fv_min_lux_trig_hi;
  float            sw_fv_min_lux_trig_lo;
} af_tuning_sw_stats_t;



typedef struct _af_header_info {
  unsigned short header_version;
  char module_name[MAX_ACT_MOD_NAME_SIZE];
  char actuator_name[MAX_ACT_NAME_SIZE];
  af_cam_name cam_name;
}af_header_info_t;


typedef struct _pdaf_loc
{
    int x,y;
} pdaf3_loc_t;
typedef struct _af_pdaf3_params
{
    //Internal Tuning Parameters
    pdaf3_loc_t RegionTopLeft,RegionBotRight;  //ROI Region for PDAF Phase Difference Calculation
    unsigned char SmoothFilter[7]; // 1D Smooth Filter
    short SobelFilter[9]; // 1D Sobel Filter
    int Confidence_k;  // Confidence Value Coefficient Q64: 64 mean 1.0
    int DefocusConfidenceTh; //Confidence Level Threshold

    //Customer Tuning Parameter
    unsigned char HorGridNumber; // Grid Number along x direction
    unsigned char VerGridNumber; // Grid Number along y direction
} af_pdaf3_params_t;


typedef struct _af_algo_tune_parms {
  af_header_info_t      af_header_info;
  af_tuning_algo_t      af_algo;
  af_tuning_sw_stats_t  af_swaf_config;
  af_tuning_vfe_t       af_vfe[MAX_AF_KERNEL_NUM];
  af_tuning_baf_t       af_baf;
  af_pdaf3_params_t        af_pdaf3;
} af_algo_tune_parms_t;

/******************************************************************************
******************************************************************************
    AF related params end
 ******************************************************************************
 ******************************************************************************/

typedef struct
{
   AAA_version_type aaa_version;
   chromatix_app_version_type chromatix_app_version;
   unsigned char is_compressed;


/******************************************************************************
    AWB
******************************************************************************/

      awb_algo_struct_type AWB_bayer_algo_data; //this contains Bayer algorithm related params

/******************************************************************************
    AEC
 ******************************************************************************/

    AEC_algo_struct_type AEC_algo_data;

/******************************************************************************
    AFD
******************************************************************************/

   chromatix_auto_flicker_detection_data_type  auto_flicker_detection_data;   // DetectionData
/******************************************************************************
    ASD
 ******************************************************************************/

    AAA_ASD_struct_type ASD_3A_algo_data;

/******************************************************************************
    AF
 ******************************************************************************/
    af_algo_tune_parms_t AF_algo_data;

/******************************************************************************
    AAA Sync (Dual Sensor)
 ******************************************************************************/
    chromatix_aaa_sync_type aaa_sync_data;

}chromatix_3a_parms_type;

#endif
